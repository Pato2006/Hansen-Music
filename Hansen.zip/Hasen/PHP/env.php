<?php
define("HOST", "localhost");
define("DB", "hansen_music");
define("USER","root");
define("PASSWORD", "");
?>