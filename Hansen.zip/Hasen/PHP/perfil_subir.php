<?php
include "env.php";
$nombre = $_POST['nombre'];
$mail = $_POST['mail'];
$nombre_compañia = $_POST['nombre_compañia'];
$entrega = $_POST['entrega'];


?>